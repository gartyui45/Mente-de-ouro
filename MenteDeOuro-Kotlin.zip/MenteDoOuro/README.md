# Mente de Ouro — Quiz do Milhão
App Android **100% Kotlin + Jetpack Compose**. Identidade azul 3D, splash, dados persistentes, modo por categoria, 6 pulos e 9 ajudas por partida.

## Voz
O projeto usa uma interface `HumanNarrator`: pronta para um provedor de voz humana **licenciado** e original. Não inclui clonagem ou imitação de pessoas reais. A implementação local atual usa o mecanismo TTS do próprio Android apenas como fallback de acessibilidade; troque pelo provedor contratado em `voice/HumanNarrator.kt`.

## Perguntas sem repetição
O histórico de perguntas respondidas fica em DataStore. O pacote vem com banco local inicial e categorias customizadas. Para quantidade realmente ilimitada, conecte um endpoint revisado no repositório (a permissão INTERNET e a interface estão preparadas); o servidor deve devolver IDs únicos e respeitar o histórico enviado pelo app.

## Compilar APK
Abra a pasta no Android Studio (JDK 17), sincronize o Gradle e escolha **Build > Build APK(s)**. O resultado será `app/build/outputs/apk/debug/app-debug.apk`.
