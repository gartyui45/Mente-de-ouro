package br.com.mentedouro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import br.com.mentedouro.data.GameData
import br.com.mentedouro.data.Question
import br.com.mentedouro.voice.HumanNarrator
import kotlinx.coroutines.launch

private val Blue=Color(0xFF071E50); private val Gold=Color(0xFFF7BE39); private val Sky=Color(0xFF1C5CB7)
class MainActivity:ComponentActivity(){ override fun onCreate(s:Bundle?){super.onCreate(s);setContent{MenteApp()}} }
@Composable fun MenteApp(){
 val context=androidx.compose.ui.platform.LocalContext.current; val scope=rememberCoroutineScope(); val narrator=remember{HumanNarrator(context)}; DisposableEffect(Unit){onDispose{narrator.release()}}
 var page by remember{mutableStateOf("home")}; var categories by remember{mutableStateOf(emptyList<String>())}; var selected by remember{mutableStateOf("")}; var best by remember{mutableIntStateOf(0)}
 LaunchedEffect(page){categories=GameData.categories(context);best=GameData.score(context)}
 MaterialTheme(colorScheme=darkColorScheme(primary=Gold,secondary=Sky,surface=Blue,background=Blue)){Surface(color=Blue,modifier=Modifier.fillMaxSize()){
  when(page){"home"->Home(best,{page="categories"},{page="manage"});"categories"->Categories(categories,{selected=it;page="game"},{page="home"});"manage"->Manage({name->scope.launch{GameData.addCategory(context,name);categories=GameData.categories(context)}},{page="home"});"game"->Game(selected,narrator,{score->scope.launch{GameData.saveScore(context,score);best=GameData.score(context)}},{page="home"})}
 }}
}
@Composable fun Home(best:Int,onPlay:()->Unit,onManage:()->Unit)=Column(Modifier.fillMaxSize().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){
 Text("MENTE",color=Color.White,fontWeight=FontWeight.Black,style=MaterialTheme.typography.displayLarge);Text("DE OURO",color=Gold,fontWeight=FontWeight.Black,style=MaterialTheme.typography.displayLarge);Spacer(Modifier.height(10.dp));Text("O quiz que transforma conhecimento em conquista",color=Color(0xFFBFD8FF),textAlign=TextAlign.Center);Spacer(Modifier.height(35.dp));Text("RECORDISTA: R$ ${best}",color=Gold);Spacer(Modifier.height(18.dp));GoldButton("JOGAR AGORA",onPlay);TextButton(onClick=onManage){Text("Criar categoria personalizada",color=Color.White)};Text("15 perguntas • 6 pulos • 9 ajudas",color=Color(0xFFBFD8FF),style=MaterialTheme.typography.labelMedium)
}
@Composable fun Categories(categories:List<String>,select:(String)->Unit,back:()->Unit)=Column(Modifier.fillMaxSize().padding(20.dp)){TextButton(back){Text("‹ Voltar",color=Gold)};Text("Escolha sua categoria",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold,color=Color.White);Text("A rodada terá 15 perguntas da categoria escolhida.",color=Color(0xFFBFD8FF));Spacer(Modifier.height(16.dp));LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(categories){c->Card(colors=CardDefaults.cardColors(containerColor=Sky),modifier=Modifier.fillMaxWidth().clickable{select(c)}){Text(c,Modifier.padding(20.dp),color=Color.White,fontWeight=FontWeight.Bold)}}}}
@Composable fun Manage(add:(String)->Unit,back:()->Unit){var name by remember{mutableStateOf("")};Column(Modifier.fillMaxSize().padding(24.dp)){TextButton(back){Text("‹ Voltar",color=Gold)};Text("Sua categoria",color=Color.White,style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.height(12.dp));OutlinedTextField(name,{name=it},label={Text("Nome da categoria")},singleLine=true);Spacer(Modifier.height(14.dp));GoldButton("ADICIONAR"){if(name.isNotBlank()){add(name);name=""}};Spacer(Modifier.height(25.dp));Text("Para conteúdo realmente personalizado, adicione um conector de banco de perguntas revisadas ao repositório. Categorias criadas já são salvas no aparelho.",color=Color(0xFFBFD8FF))}}
@Composable fun Game(category:String,narrator:HumanNarrator,save:(Int)->Unit,exit:()->Unit){
 val context=androidx.compose.ui.platform.LocalContext.current; val scope=rememberCoroutineScope(); var questions by remember{mutableStateOf(emptyList<Question>())};var i by remember{mutableIntStateOf(0)};var skips by remember{mutableIntStateOf(6)};var helps by remember{mutableIntStateOf(9)};var locked by remember{mutableStateOf(false)};var message by remember{mutableStateOf("")};var score by remember{mutableIntStateOf(0)};var hidden by remember{mutableStateOf(setOf<Int>())}
 LaunchedEffect(category){val seen=GameData.seen(context);questions=GameData.initialQuestions(category).filter{it.id !in seen};if(questions.size<15)questions=GameData.initialQuestions(category).shuffled();narrator.say("Bem-vindo ao Mente de Ouro. Categoria $category.")}
 if(questions.isEmpty())return Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){CircularProgressIndicator(color=Gold)}
 val q=questions[i]; fun next(){scope.launch{GameData.markSeen(context,q.id)};if(i==14){save(score);message="Rodada concluída! Você conquistou R$ $score";locked=true}else{i++;locked=false;hidden=emptySet();message=""}}
 Column(Modifier.fillMaxSize().padding(18.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(category,color=Gold,fontWeight=FontWeight.Bold);Text("${i+1}/15",color=Color.White)};LinearProgressIndicator((i+1)/15f,Modifier.fillMaxWidth().padding(vertical=10.dp),color=Gold,trackColor=Sky);Text("R$ $score",color=Gold,style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Black);Spacer(Modifier.height(15.dp));Card(colors=CardDefaults.cardColors(containerColor=Sky),modifier=Modifier.fillMaxWidth()){Text(q.text,Modifier.padding(22.dp),color=Color.White,style=MaterialTheme.typography.titleLarge,textAlign=TextAlign.Center)};Spacer(Modifier.height(12.dp));q.answers.forEachIndexed{index,a->if(index !in hidden)OutlinedButton(onClick={if(!locked){locked=true;if(index==q.right){score+=(i+1)*1000;message="Resposta certa!";narrator.say("Resposta certa!")}else{message="Não foi dessa vez. A resposta era ${q.answers[q.right]}.";narrator.say(message)};save(score)}},modifier=Modifier.fillMaxWidth().padding(vertical=4.dp),colors=ButtonDefaults.outlinedButtonColors(contentColor=Color.White)){Text(a)}};Spacer(Modifier.weight(1f));Text(message,color=Gold);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){OutlinedButton(onClick={if(skips>0&&!locked){skips--;next()}},enabled=skips>0&&!locked){Text("PULAR $skips")};OutlinedButton(onClick={if(helps>0&&!locked){helps--;hidden=q.answers.indices.filter{it!=q.right}.shuffled().take(2).toSet();message="Duas alternativas foram eliminadas."}},enabled=helps>0&&!locked){Text("AJUDA $helps")};Button(onClick={if(locked){if(i==14)exit()else next()}else narrator.say(q.text)},colors=ButtonDefaults.buttonColors(containerColor=Gold,contentColor=Blue)){Text(if(locked)if(i==14)"FINALIZAR" else "PRÓXIMA" else "OUVIR")}}}
}
@Composable fun GoldButton(text:String,click:()->Unit)=Button(click,colors=ButtonDefaults.buttonColors(containerColor=Gold,contentColor=Blue),shape=RoundedCornerShape(14.dp),modifier=Modifier.fillMaxWidth().height(54.dp)){Text(text,fontWeight=FontWeight.Black)}
