package br.com.mentedouro.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first

private val Context.store by preferencesDataStore("mente_ouro")
data class Question(val id:String,val category:String,val text:String,val answers:List<String>,val right:Int)
object GameData {
 val standard = listOf("Conhecimentos Gerais","Brasil","História","Geografia","Ciências","Esportes","Cinema & TV","Música","Literatura","Tecnologia")
 private val facts = listOf(
  Triple("Qual é a capital do Brasil?","Brasília","Rio de Janeiro|São Paulo|Salvador"), Triple("Qual planeta é conhecido como Planeta Vermelho?","Marte","Vênus|Júpiter|Saturno"), Triple("Quantos lados tem um hexágono?","6","5|7|8"), Triple("Qual é o maior oceano do planeta?","Pacífico","Atlântico|Índico|Ártico"), Triple("Quem escreveu Dom Casmurro?","Machado de Assis","José de Alencar|Clarice Lispector|Jorge Amado"), Triple("Qual elemento químico tem símbolo O?","Oxigênio","Ouro|Ósmio|Hidrogênio"), Triple("Em que país ficam as pirâmides de Gizé?","Egito","Grécia|México|Itália"), Triple("Qual é a moeda do Japão?","Iene","Won|Yuan|Rúpia"), Triple("Qual é o maior mamífero do mundo?","Baleia-azul","Elefante|Girafa|Orca"), Triple("Quantos minutos tem uma hora?","60","30|90|100"), Triple("Qual gás as plantas absorvem na fotossíntese?","Gás carbônico","Oxigênio|Nitrogênio|Hélio"), Triple("Qual esporte usa cesta e bola?","Basquete","Vôlei|Tênis|Golfe"), Triple("Quem pintou Mona Lisa?","Leonardo da Vinci","Van Gogh|Picasso|Michelangelo"), Triple("Qual é a primeira letra do alfabeto grego?","Alfa","Beta|Gama|Ômega"), Triple("Qual instrumento possui teclas pretas e brancas?","Piano","Violino|Flauta|Tambor")
 )
 fun initialQuestions(category:String): List<Question> = facts.mapIndexed { i,f ->
  val wrong=f.third.split("|"); val answers=(wrong+f.second).shuffled(); Question("$category-$i",category,f.first,answers,answers.indexOf(f.second))
 }
 suspend fun categories(context:Context):List<String> = standard + (context.store.data.first()[stringSetPreferencesKey("custom_categories")] ?: emptySet())
 suspend fun addCategory(context:Context, name:String) { context.store.edit { it[stringSetPreferencesKey("custom_categories")]=(it[stringSetPreferencesKey("custom_categories")]?:emptySet())+name.trim() } }
 suspend fun seen(context:Context):Set<String> = context.store.data.first()[stringSetPreferencesKey("seen")] ?: emptySet()
 suspend fun markSeen(context:Context,id:String) { context.store.edit { it[stringSetPreferencesKey("seen")]=(it[stringSetPreferencesKey("seen")]?:emptySet())+id } }
 suspend fun score(context:Context):Int=context.store.data.first()[intPreferencesKey("best_score")]?:0
 suspend fun saveScore(context:Context,value:Int){context.store.edit{if(value>(it[intPreferencesKey("best_score")]?:0))it[intPreferencesKey("best_score")]=value}}
}
