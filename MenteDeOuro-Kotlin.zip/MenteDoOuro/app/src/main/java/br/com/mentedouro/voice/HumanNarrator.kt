package br.com.mentedouro.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * Ponto de integração para uma voz profissional original e licenciada.
 * Não use clonagem ou imitação de pessoas reais sem autorização explícita.
 */
class HumanNarrator(context: Context) {
    private lateinit var tts: TextToSpeech

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) tts.language = Locale("pt", "BR")
        }
    }

    /** Fallback local de acessibilidade; substitua por SDK de locução licenciada em produção. */
    fun say(text: String) {
        tts.setPitch(.92f)
        tts.setSpeechRate(.94f)
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "quiz")
    }
    fun release() = tts.shutdown()
}
