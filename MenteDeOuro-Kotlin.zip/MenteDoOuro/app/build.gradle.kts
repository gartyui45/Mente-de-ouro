plugins { id("com.android.application"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.compose") }

android { buildFeatures { compose = true }; namespace = "br.com.mentedouro"; compileSdk = 35
 defaultConfig { applicationId = "br.com.mentedouro"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0.0" }
}
kotlin { jvmToolchain(17) }

dependencies {
 implementation(platform("androidx.compose:compose-bom:2024.09.03"))
 implementation("androidx.core:core-ktx:1.13.1")
 implementation("androidx.activity:activity-compose:1.9.2")
 implementation("androidx.compose.ui:ui")
 implementation("androidx.compose.ui:ui-tooling-preview")
 implementation("androidx.compose.material3:material3")
 implementation("androidx.datastore:datastore-preferences:1.1.1")
 implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
 debugImplementation("androidx.compose.ui:ui-tooling")
}
